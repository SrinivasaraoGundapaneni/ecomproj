/** @type {import('postcss-load-config').Config} */
const config = {
  plugins: {
  },
};

export default config;
