interface Facts {
    name: string;
    counter: string;
    discription: string;
    item: number;
  }
  
  const facts: Facts[] = [
    {
      counter: "65K+",
      discription: "Contrary to popular belief, Lorem is not simply random text.",
      name: "Vendors",
      item: 320,
    },
    {
      counter: "$45B+",
      discription: "Contrary to popular belief, Lorem is not simply random text.",
      name: "Earnings",
      item: 65,
    },
    {
      counter: "25M+",
      discription: "Contrary to popular belief, Lorem is not simply random text.",
      name: "Sold",
      item: 548,
    },
    {
      counter: "70K+",
      discription: "Contrary to popular belief, Lorem is not simply random text.",
      name: "Products",
      item: 48,
    },
    
  ];
  export default facts;
  