interface Policy {
    questions: string;
  }
  
  const policy: Policy[] = [
    {
      questions: "Welcome to Grabit Store.",
    },
    {
      questions: "Grabit Websites",
    },
    {
      questions: "How browsing and vendor works?",
    },
    {
      questions: "Becoming an vendor",
    },
    
  ];
  export default policy;
  