interface Questions {
    questions: string;
    ans: string;
  }
  
  const questionstwo: Questions[] = [
    {
      questions: "Refund policy for customer.",
      ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard <code>dummy text</code> ever since the 1500s,when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    },
    {
      questions: "Exchange policy for customer.",
      ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard <code>dummy text</code> ever since the 1500s,when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    },
    {
      questions: "How to buy many products at a time?",
      ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard <code>dummy text</code> ever since the 1500s,when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    },
    {
      questions: "Give a way products available.",
      ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard <code>dummy text</code> ever since the 1500s,when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    },
    {
      questions: "What is the multi vendor services?",
      ans: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard <code>dummy text</code> ever since the 1500s,when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    },
  ];
  export default questionstwo;
  