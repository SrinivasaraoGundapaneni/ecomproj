interface Price {
    name: string;
  }
  
  const price: Price[] = [
    {
      name: "Under $100",
    },
    {
      name: "$100 - $500",
    },
    {
      name: "$500 - $1000",
      
    },    
  ];
  export default price