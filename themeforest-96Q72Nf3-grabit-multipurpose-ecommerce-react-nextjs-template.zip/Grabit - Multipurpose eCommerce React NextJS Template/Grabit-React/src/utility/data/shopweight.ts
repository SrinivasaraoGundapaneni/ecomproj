interface Weight {
  waight: string;
}

const shopweight: Weight[] = [
  {
    waight: "500g",
  },
  {
    waight: "1kg",
  },
  {
    waight: "2pack",
  },
  {
    waight: "2kg",
  },
  {
    waight: "5kg",
  },
  {
    waight: "10kg",
  },
];
export default shopweight;
