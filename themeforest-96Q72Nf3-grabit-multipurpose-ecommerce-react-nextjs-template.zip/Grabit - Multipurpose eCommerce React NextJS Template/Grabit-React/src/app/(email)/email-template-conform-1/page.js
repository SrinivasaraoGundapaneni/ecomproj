import EmailTemplateOne from "@/components/email/email-conform/EmailTemplateOne"

const page = () => {
    return (
        <>
            <EmailTemplateOne />
        </>
    )
}

export default page