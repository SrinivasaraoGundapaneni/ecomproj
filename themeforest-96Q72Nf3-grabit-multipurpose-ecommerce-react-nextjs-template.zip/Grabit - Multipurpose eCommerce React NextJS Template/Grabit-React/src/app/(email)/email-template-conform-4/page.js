import EmailTemplateFour from "@/components/email/email-conform/EmailTemplateFour"

const page = () => {
  return (
    <>
      <EmailTemplateFour />
    </>
  )
}

export default page