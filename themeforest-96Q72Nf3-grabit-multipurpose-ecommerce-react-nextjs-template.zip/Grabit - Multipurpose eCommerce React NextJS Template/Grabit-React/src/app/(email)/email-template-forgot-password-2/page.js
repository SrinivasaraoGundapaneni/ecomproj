import EmailForgetPasswordTwo from "@/components/email/email-forgot/EmailForgetPasswordTwo"
const page = () => {
  return (
    <>
      <EmailForgetPasswordTwo />
    </>
  )
}

export default page