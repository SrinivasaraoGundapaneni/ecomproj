import EmailForgetPasswordFour from "@/components/email/email-forgot/EmailForgetPasswordFour"
const page = () => {
  return (
    <>
      <EmailForgetPasswordFour />
    </>
  )
}

export default page