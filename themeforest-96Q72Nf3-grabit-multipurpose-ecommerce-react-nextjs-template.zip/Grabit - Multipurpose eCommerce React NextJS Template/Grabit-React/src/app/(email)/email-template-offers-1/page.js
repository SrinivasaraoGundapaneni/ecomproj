import EmailOfferOne from "@/components/email/email-offer/EmailOfferOne"

const page = () => {
  return (
    <>
      <EmailOfferOne />
    </>
  )
}

export default page