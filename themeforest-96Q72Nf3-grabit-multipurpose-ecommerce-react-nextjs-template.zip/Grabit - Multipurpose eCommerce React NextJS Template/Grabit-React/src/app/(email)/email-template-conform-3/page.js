import EmailTemplateThree from "@/components/email/email-conform/EmailTemplateThree"

const page = () => {
  return (
    <>
      <EmailTemplateThree />
    </>
  )
}

export default page