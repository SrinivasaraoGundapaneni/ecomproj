import RegisterPage from '@/components/login/RegisterPage'

const page = () => <RegisterPage />

export default page