import Category from "../category/Category";

const SidebarCategory = ({ className }) => {
  return (
    <>
      <Category className={className} />
    </>
  );
};

export default SidebarCategory;
