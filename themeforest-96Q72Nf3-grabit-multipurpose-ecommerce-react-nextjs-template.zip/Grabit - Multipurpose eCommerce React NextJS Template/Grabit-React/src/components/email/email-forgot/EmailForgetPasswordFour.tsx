const EmailForgetPasswordFour = () => {
  return (
    <>
      <table
        style={{
          tableLayout: "fixed",
          verticalAlign: "top",
          minWidth: "320px",
          borderSpacing: "0",
          borderCollapse: "collapse",
          backgroundColor: "#f1d0ff",
          width: "100%",
          userSelect: "none",
        }}
        width="100%"
        cellSpacing="0"
        cellPadding="0"
        bgcolor="#000000"
      >
        <tbody>
          <tr style={{ verticalAlign: "top" }}>
            <td
              style={{ wordBreak: "break-word", verticalAlign: "top" }}
              valign="top"
            >
              <table width="100%" cellSpacing="0" cellPadding="0" border={0}>
                <tbody>
                  <tr>
                    <td style={{ backgroundColor: "#000000" }} align="center">
                      <div style={{ backgroundColor: "#fff" }}>
                        <div
                          style={{
                            minWidth: "320px",
                            maxWidth: "650px",
                            overflowWrap: "break-word",
                            wordWrap: "break-word",
                            wordBreak: "break-word",
                            margin: "0 auto",
                          }}
                        >
                          <div
                            style={{
                              borderCollapse: "collapse",
                              display: "table",
                              width: "100%",
                            }}
                          >
                            <table
                              style={{ backgroundColor: "#cffeed" }}
                              width="100%"
                              cellSpacing="0"
                              cellPadding="0"
                              border={0}
                            >
                              <tbody>
                                <tr>
                                  <td align="center">
                                    <table
                                      style={{ width: "650px" }}
                                      cellSpacing="0"
                                      cellPadding="0"
                                      border={0}
                                    >
                                      <tbody>
                                        <tr
                                          style={{
                                            backgroundColor: "transparent",
                                          }}
                                        >
                                          <td
                                            style={{
                                              backgroundColor: "transparent",
                                              width: "650px",
                                              borderTop:
                                                "0px solid transparent",
                                              borderLeft:
                                                "0px solid transparent",
                                              borderBottom:
                                                "0px solid transparent",
                                              borderRight:
                                                "0px solid transparent",
                                            }}
                                            width="650"
                                            valign="top"
                                            align="center"
                                          >
                                            <table
                                              width="100%"
                                              cellSpacing="0"
                                              cellPadding="0"
                                              border={0}
                                            >
                                              <tbody>
                                                <tr>
                                                  <td
                                                    style={{
                                                      paddingRight: "0px",
                                                      paddingLeft: "0px",
                                                      paddingTop: "5px",
                                                      paddingBottom: "5px",
                                                    }}
                                                  >
                                                    <div
                                                      style={{
                                                        minWidth: "320px",
                                                        maxWidth: "650px",
                                                        display: "table-cell",
                                                        verticalAlign: "top",
                                                        width: "650px",
                                                      }}
                                                    >
                                                      <div
                                                        style={{
                                                          width:
                                                            "100% !important",
                                                        }}
                                                      >
                                                        <div
                                                          style={{
                                                            border:
                                                              "0px solid transparent",
                                                            padding:
                                                              "5px 0px 5px 0px",
                                                          }}
                                                        >
                                                          <div
                                                            style={{
                                                              paddingRight:
                                                                "0px",
                                                              paddingLeft:
                                                                "0px",
                                                              textAlign:
                                                                "center",
                                                            }}
                                                          >
                                                            <table
                                                              width="100%"
                                                              cellSpacing="0"
                                                              cellPadding="0"
                                                              border={0}
                                                            >
                                                              <tbody>
                                                                <tr
                                                                  style={{
                                                                    lineHeight:
                                                                      "0px",
                                                                  }}
                                                                >
                                                                  <td
                                                                    style={{
                                                                      paddingRight:
                                                                        "0px",
                                                                      paddingLeft:
                                                                        "0px",
                                                                    }}
                                                                    align="center"
                                                                  >
                                                                    <div
                                                                      style={{
                                                                        fontSize:
                                                                          "1px",
                                                                        lineHeight:
                                                                          "15px",
                                                                      }}
                                                                    >
                                                                      &nbsp;
                                                                    </div>
                                                                    <img
                                                                      style={{
                                                                        textDecoration:
                                                                          "none",
                                                                        imageRendering:
                                                                          "pixelated",
                                                                        height:
                                                                          "auto",
                                                                        border:
                                                                          "0",
                                                                        width:
                                                                          "100%",
                                                                        maxWidth:
                                                                          "130px",
                                                                        display:
                                                                          "block",
                                                                        textAlign:
                                                                          "center",
                                                                      }}
                                                                      title="your logo"
                                                                      alt="your logo"
                                                                      src={
                                                                        process
                                                                          .env
                                                                          .NEXT_PUBLIC_URL +
                                                                        "/assets/img/logo/logo.png"
                                                                      }
                                                                      width="130"
                                                                    />
                                                                    <div
                                                                      style={{
                                                                        fontSize:
                                                                          "1px",
                                                                        lineHeight:
                                                                          "25px",
                                                                      }}
                                                                    >
                                                                      &nbsp;
                                                                    </div>
                                                                  </td>
                                                                </tr>
                                                              </tbody>
                                                            </table>
                                                          </div>
                                                        </div>
                                                      </div>
                                                    </div>
                                                  </td>
                                                </tr>
                                              </tbody>
                                            </table>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                      <div style={{ backgroundColor: "#fff" }}>
                        <div
                          style={{
                            minWidth: "320px",
                            maxWidth: "650px",
                            overflowWrap: "break-word",
                            wordWrap: "break-word",
                            wordBreak: "break-word",
                            margin: "0 auto",
                          }}
                        >
                          <div
                            style={{
                              borderCollapse: "collapse",
                              display: "table",
                              width: "100%",
                            }}
                          >
                            <table
                              width="100%"
                              cellSpacing="0"
                              cellPadding="0"
                              border={0}
                            >
                              <tbody>
                                <tr>
                                  <td align="center">
                                    <table
                                      style={{ width: "650px" }}
                                      cellSpacing="0"
                                      cellPadding="0"
                                      border={0}
                                    >
                                      <tbody>
                                        <tr
                                          style={{ backgroundColor: "#f1d0ff" }}
                                        >
                                          <td
                                            style={{
                                              backgroundColor: "#4c5966",
                                              width: "650px",
                                              borderTop:
                                                "0px solid transparent",
                                              borderLeft:
                                                "0px solid transparent",
                                              borderBottom:
                                                "0px solid transparent",
                                              borderRight:
                                                "0px solid transparent",
                                            }}
                                            width="650"
                                            valign="top"
                                            align="center"
                                          >
                                            <table
                                              width="100%"
                                              cellSpacing="0"
                                              cellPadding="0"
                                              border={0}
                                            >
                                              <tbody>
                                                <tr>
                                                  <td>
                                                    <div
                                                      style={{
                                                        minWidth: "320px",
                                                        maxWidth: "650px",
                                                        display: "table-cell",
                                                        verticalAlign: "top",
                                                        width: "650px",
                                                      }}
                                                    >
                                                      <div
                                                        style={{
                                                          width:
                                                            "100% !important",
                                                        }}
                                                      >
                                                        <div
                                                          style={{
                                                            border:
                                                              "0px solid transparent",
                                                            padding: "0",
                                                          }}
                                                        >
                                                          <div
                                                            style={{
                                                              textAlign:
                                                                "center",
                                                            }}
                                                          >
                                                            <table
                                                              width="100%"
                                                              cellSpacing="0"
                                                              cellPadding="0"
                                                              border={0}
                                                              style={{
                                                                tableLayout:
                                                                  "fixed",
                                                                borderSpacing: 0,
                                                                borderCollapse:
                                                                  "collapse",
                                                              }}
                                                            >
                                                              <tbody>
                                                                <tr
                                                                  style={{
                                                                    lineHeight: 0,
                                                                  }}
                                                                >
                                                                  <td align="center">
                                                                    <img
                                                                      style={{
                                                                        textDecoration:
                                                                          "none",
                                                                        imageRendering:
                                                                          "pixelated",
                                                                        height:
                                                                          "auto",
                                                                        border: 0,
                                                                        width:
                                                                          "100%",
                                                                        maxWidth:
                                                                          "100%",
                                                                        display:
                                                                          "block",
                                                                      }}
                                                                      title="Forgot your password?"
                                                                      alt="Forgot your password?"
                                                                      src={
                                                                        process
                                                                          .env
                                                                          .NEXT_PUBLIC_URL +
                                                                        "/assets/img/email/5.jpg"
                                                                      }
                                                                      width="325"
                                                                    />
                                                                  </td>
                                                                </tr>
                                                              </tbody>
                                                            </table>
                                                          </div>

                                                          <table
                                                            width="100%"
                                                            cellSpacing="0"
                                                            cellPadding="0"
                                                            style={{
                                                              tableLayout:
                                                                "fixed",
                                                              verticalAlign:
                                                                "top",
                                                              borderSpacing: 0,
                                                              borderCollapse:
                                                                "collapse",
                                                            }}
                                                          >
                                                            <tbody>
                                                              <tr
                                                                style={{
                                                                  verticalAlign:
                                                                    "top",
                                                                }}
                                                              >
                                                                <td
                                                                  style={{
                                                                    wordBreak:
                                                                      "break-word",
                                                                    verticalAlign:
                                                                      "top",
                                                                    textAlign:
                                                                      "center",
                                                                    width:
                                                                      "100%",
                                                                    padding:
                                                                      "35px 0 0 0",
                                                                  }}
                                                                  align="center"
                                                                  valign="top"
                                                                >
                                                                  <h1
                                                                    style={{
                                                                      color:
                                                                        "#fff",
                                                                      direction:
                                                                        "ltr",
                                                                      fontFamily:
                                                                        "'Cabin', Arial, 'Helvetica Neue', Helvetica, sans-serif",
                                                                      fontSize:
                                                                        "28px",
                                                                      fontWeight:
                                                                        "normal",
                                                                      letterSpacing:
                                                                        "normal",
                                                                      lineHeight:
                                                                        "120%",
                                                                      textAlign:
                                                                        "center",
                                                                      marginTop: 0,
                                                                      marginBottom: 0,
                                                                    }}
                                                                  >
                                                                    <strong>
                                                                      Forgot
                                                                      your
                                                                      password?
                                                                    </strong>
                                                                  </h1>
                                                                </td>
                                                              </tr>
                                                            </tbody>
                                                          </table>
                                                          <table
                                                            width="100%"
                                                            cellSpacing="0"
                                                            cellPadding="0"
                                                            border={0}
                                                            style={{
                                                              fontFamily:
                                                                "Arial, sans-serif",
                                                              paddingRight:
                                                                "45px",
                                                              paddingLeft:
                                                                "45px",
                                                              paddingTop:
                                                                "10px",
                                                              paddingBottom:
                                                                "0px",
                                                            }}
                                                          >
                                                            <tbody>
                                                              <tr>
                                                                <td>
                                                                  <div
                                                                    style={{
                                                                      color:
                                                                        "#393d47",
                                                                      fontFamily:
                                                                        "'Cabin', Arial, 'Helvetica Neue', Helvetica, sans-serif",
                                                                      lineHeight: 1.5,
                                                                      padding:
                                                                        "10px 45px 0px 45px",
                                                                    }}
                                                                  >
                                                                    <div
                                                                      style={{
                                                                        lineHeight: 1.5,
                                                                        fontSize:
                                                                          "12px",
                                                                        fontFamily:
                                                                          "'Cabin', Arial, 'Helvetica Neue', Helvetica, sans-serif",
                                                                        color:
                                                                          "#393d47",
                                                                      }}
                                                                    >
                                                                      <p
                                                                        style={{
                                                                          textAlign:
                                                                            "center",
                                                                          lineHeight: 1.5,
                                                                          wordBreak:
                                                                            "break-word",
                                                                          fontFamily:
                                                                            "'Cabin', Arial, 'Helvetica Neue', Helvetica, sans-serif",
                                                                          fontSize:
                                                                            "18px",
                                                                          margin:
                                                                            "0",
                                                                        }}
                                                                      >
                                                                        <span
                                                                          style={{
                                                                            fontSize:
                                                                              "18px",
                                                                            color:
                                                                              "#fff",
                                                                          }}
                                                                        >
                                                                          We
                                                                          received
                                                                          a
                                                                          request
                                                                          to
                                                                          reset
                                                                          your
                                                                          password.
                                                                        </span>
                                                                      </p>
                                                                      <p
                                                                        style={{
                                                                          textAlign:
                                                                            "center",
                                                                          lineHeight: 1.5,
                                                                          wordBreak:
                                                                            "break-word",
                                                                          fontFamily:
                                                                            "'Cabin', Arial, 'Helvetica Neue', Helvetica, sans-serif",
                                                                          fontSize:
                                                                            "18px",
                                                                          margin:
                                                                            "0",
                                                                        }}
                                                                      >
                                                                        <span
                                                                          style={{
                                                                            fontSize:
                                                                              "18px",
                                                                            color:
                                                                              "#fff",
                                                                          }}
                                                                        >
                                                                          If you
                                                                          didn t
                                                                          make
                                                                          this
                                                                          request,
                                                                          simply
                                                                          ignore
                                                                          this
                                                                          email.
                                                                        </span>
                                                                      </p>
                                                                    </div>
                                                                  </div>
                                                                </td>
                                                              </tr>
                                                            </tbody>
                                                          </table>

                                                          <table
                                                            width="100%"
                                                            cellSpacing="0"
                                                            cellPadding="0"
                                                            border={0}
                                                            style={{
                                                              tableLayout:
                                                                "fixed",
                                                              verticalAlign:
                                                                "top",
                                                              borderSpacing: 0,
                                                              borderCollapse:
                                                                "collapse",
                                                              minWidth: "100%",
                                                              height: "100%",
                                                            }}
                                                          >
                                                            <tbody>
                                                              <tr
                                                                style={{
                                                                  verticalAlign:
                                                                    "top",
                                                                }}
                                                              >
                                                                <td
                                                                  style={{
                                                                    wordBreak:
                                                                      "break-word",
                                                                    verticalAlign:
                                                                      "top",
                                                                    minWidth:
                                                                      "100%",
                                                                    height:
                                                                      "100%",
                                                                    padding:
                                                                      "20px",
                                                                  }}
                                                                >
                                                                  <table
                                                                    width="80%"
                                                                    cellSpacing="0"
                                                                    cellPadding="0"
                                                                    border={0}
                                                                    align="center"
                                                                    style={{
                                                                      tableLayout:
                                                                        "fixed",
                                                                      verticalAlign:
                                                                        "top",
                                                                      borderSpacing: 0,
                                                                      borderCollapse:
                                                                        "collapse",
                                                                      borderTop:
                                                                        "1px solid #D5E2E6",
                                                                      width:
                                                                        "80%",
                                                                    }}
                                                                  >
                                                                    <tbody>
                                                                      <tr
                                                                        style={{
                                                                          verticalAlign:
                                                                            "top",
                                                                        }}
                                                                      >
                                                                        <td
                                                                          style={{
                                                                            wordBreak:
                                                                              "break-word",
                                                                            verticalAlign:
                                                                              "top",
                                                                            height:
                                                                              "100%",
                                                                          }}
                                                                        >
                                                                          &nbsp;
                                                                        </td>
                                                                      </tr>
                                                                    </tbody>
                                                                  </table>
                                                                </td>
                                                              </tr>
                                                            </tbody>
                                                          </table>

                                                          <table
                                                            width="100%"
                                                            cellSpacing="0"
                                                            cellPadding="0"
                                                            border={0}
                                                            style={{
                                                              fontFamily:
                                                                "Arial, sans-serif",
                                                              paddingRight:
                                                                "45px",
                                                              paddingLeft:
                                                                "45px",
                                                              paddingTop:
                                                                "10px",
                                                              paddingBottom:
                                                                "10px",
                                                            }}
                                                          >
                                                            <tbody>
                                                              <tr>
                                                                <td>
                                                                  <div
                                                                    style={{
                                                                      color:
                                                                        "#393d47",
                                                                      fontFamily:
                                                                        "'Cabin', Arial, 'Helvetica Neue', Helvetica, sans-serif",
                                                                      lineHeight: 1.5,
                                                                      padding:
                                                                        "10px 45px 10px 45px",
                                                                      textAlign:
                                                                        "center",
                                                                    }}
                                                                  >
                                                                    <span
                                                                      style={{
                                                                        fontSize:
                                                                          "15px",
                                                                        color:
                                                                          "#fff",
                                                                      }}
                                                                    >
                                                                      If you did
                                                                      make this
                                                                      request
                                                                      just click
                                                                      the button
                                                                      below:
                                                                    </span>
                                                                  </div>
                                                                </td>
                                                              </tr>
                                                            </tbody>
                                                          </table>
                                                          <div
                                                            style={{
                                                              padding: "10px",
                                                              textAlign:
                                                                "center",
                                                            }}
                                                          >
                                                            <table
                                                              width="100%"
                                                              cellSpacing="0"
                                                              cellPadding="0"
                                                              border={0}
                                                              style={{
                                                                borderSpacing: 0,
                                                                borderCollapse:
                                                                  "collapse",
                                                              }}
                                                            >
                                                              <tbody>
                                                                <tr>
                                                                  <td
                                                                    style={{
                                                                      paddingTop:
                                                                        "10px",
                                                                      paddingRight:
                                                                        "10px",
                                                                      paddingBottom:
                                                                        "10px",
                                                                      paddingLeft:
                                                                        "10px",
                                                                    }}
                                                                    align="center"
                                                                  >
                                                                    {/* VML Roundrect (rendered for Outlook) */}
                                                                    <table
                                                                      style={{
                                                                        height:
                                                                          "40.5pt",
                                                                        width:
                                                                          "236.25pt",
                                                                        backgroundColor:
                                                                          "#5daf92",
                                                                        borderRadius:
                                                                          "5px",
                                                                        color:
                                                                          "#ffffff",
                                                                        fontFamily:
                                                                          "Arial, sans-serif",
                                                                        fontSize:
                                                                          "14px",
                                                                        lineHeight:
                                                                          "2",
                                                                        textAlign:
                                                                          "center",
                                                                        wordBreak:
                                                                          "keep-all",
                                                                      }}
                                                                      cellSpacing="0"
                                                                      cellPadding="0"
                                                                      border={0}
                                                                      align="center"
                                                                    >
                                                                      <tbody>
                                                                        <tr>
                                                                          <td
                                                                            style={{
                                                                              verticalAlign:
                                                                                "middle",
                                                                              padding:
                                                                                "10px 40px",
                                                                              fontSize:
                                                                                "14px",
                                                                              lineHeight:
                                                                                "28px",
                                                                            }}
                                                                          >
                                                                            <a
                                                                              href="javascript:void(0)"
                                                                              style={{
                                                                                textDecoration:
                                                                                  "none",
                                                                                color:
                                                                                  "#fff",
                                                                                display:
                                                                                  "inline-block",
                                                                                width:
                                                                                  "auto",
                                                                                fontWeight:
                                                                                  "700",
                                                                              }}
                                                                            >
                                                                              RESET
                                                                              MY
                                                                              PASSWORD
                                                                            </a>
                                                                          </td>
                                                                        </tr>
                                                                      </tbody>
                                                                    </table>
                                                                  </td>
                                                                </tr>
                                                              </tbody>
                                                            </table>
                                                          </div>

                                                          <table
                                                            width="100%"
                                                            cellSpacing="0"
                                                            cellPadding="0"
                                                            border={0}
                                                          >
                                                            <tbody>
                                                              <tr>
                                                                <td
                                                                  style={{
                                                                    paddingRight:
                                                                      "10px",
                                                                    paddingLeft:
                                                                      "10px",
                                                                    paddingTop:
                                                                      "10px",
                                                                    paddingBottom:
                                                                      "15px",
                                                                    fontFamily:
                                                                      "Arial, sans-serif",
                                                                  }}
                                                                >
                                                                  <div
                                                                    style={{
                                                                      color:
                                                                        "#fff",
                                                                      fontFamily:
                                                                        "'Cabin', Arial, 'Helvetica Neue', Helvetica, sans-serif",
                                                                      lineHeight:
                                                                        "1.2",
                                                                      padding:
                                                                        "10px 10px 15px 10px",
                                                                    }}
                                                                  >
                                                                    <div
                                                                      style={{
                                                                        lineHeight:
                                                                          "1.2",
                                                                        fontSize:
                                                                          "12px",
                                                                        color:
                                                                          "#393d47",
                                                                        fontFamily:
                                                                          "'Cabin', Arial, 'Helvetica Neue', Helvetica, sans-serif",
                                                                      }}
                                                                    >
                                                                      <p
                                                                        style={{
                                                                          color:
                                                                            "#fff",
                                                                          fontSize:
                                                                            "10px",
                                                                          lineHeight:
                                                                            "1.2",
                                                                          wordBreak:
                                                                            "break-word",
                                                                          textAlign:
                                                                            "center",
                                                                          margin:
                                                                            "0",
                                                                        }}
                                                                      >
                                                                        If you
                                                                        didn `t
                                                                        request
                                                                        to
                                                                        change
                                                                        your
                                                                        brand
                                                                        password,
                                                                        you don
                                                                        t have
                                                                        to do
                                                                        anything.
                                                                        So that
                                                                        s easy.
                                                                      </p>
                                                                    </div>
                                                                  </div>
                                                                </td>
                                                              </tr>
                                                            </tbody>
                                                          </table>

                                                          <table
                                                            width="100%"
                                                            cellSpacing="0"
                                                            cellPadding="0"
                                                            border={0}
                                                          >
                                                            <tbody>
                                                              <tr>
                                                                <td
                                                                  style={{
                                                                    paddingRight:
                                                                      "10px",
                                                                    paddingLeft:
                                                                      "10px",
                                                                    paddingTop:
                                                                      "10px",
                                                                    paddingBottom:
                                                                      "20px",
                                                                    fontFamily:
                                                                      "Arial, sans-serif",
                                                                  }}
                                                                >
                                                                  <div
                                                                    style={{
                                                                      color:
                                                                        "#393d47",
                                                                      fontFamily:
                                                                        "Arial, Helvetica Neue, Helvetica, sans-serif",
                                                                      lineHeight:
                                                                        "1.2",
                                                                      padding:
                                                                        "10px 10px 20px 10px",
                                                                    }}
                                                                  >
                                                                    <div
                                                                      style={{
                                                                        lineHeight:
                                                                          "1.2",
                                                                        fontSize:
                                                                          "12px",
                                                                        color:
                                                                          "#393d47",
                                                                        fontFamily:
                                                                          "Arial, Helvetica Neue, Helvetica, sans-serif",
                                                                      }}
                                                                    >
                                                                      <p
                                                                        style={{
                                                                          fontSize:
                                                                            "14px",
                                                                          lineHeight:
                                                                            "1.2",
                                                                          wordBreak:
                                                                            "break-word",
                                                                          textAlign:
                                                                            "center",
                                                                          margin:
                                                                            "0",
                                                                        }}
                                                                      >
                                                                        <a
                                                                          href="#"
                                                                          rel="noopener"
                                                                          style={{
                                                                            color:
                                                                              "#fff",
                                                                            fontWeight:
                                                                              "600",
                                                                          }}
                                                                        >
                                                                          Unsubscribe
                                                                        </a>
                                                                      </p>
                                                                    </div>
                                                                  </div>
                                                                </td>
                                                              </tr>
                                                            </tbody>
                                                          </table>
                                                        </div>
                                                      </div>
                                                    </div>
                                                  </td>
                                                </tr>
                                              </tbody>
                                            </table>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
    </>
  );
};

export default EmailForgetPasswordFour;
